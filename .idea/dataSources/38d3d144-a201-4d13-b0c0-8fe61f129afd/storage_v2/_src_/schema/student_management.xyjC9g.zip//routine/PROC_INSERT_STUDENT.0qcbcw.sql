create
    definer = root@localhost procedure PROC_INSERT_STUDENT(IN name_ varchar(20), IN birthday_ date, IN class_id_ int)
begin
    INSERT INTO student(student_name, birthday, class_id) values (name_,birthday_,class_id_);
end;

