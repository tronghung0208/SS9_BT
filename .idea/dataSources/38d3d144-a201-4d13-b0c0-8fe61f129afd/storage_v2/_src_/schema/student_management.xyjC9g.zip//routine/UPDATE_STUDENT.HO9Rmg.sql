create
    definer = root@localhost procedure UPDATE_STUDENT(IN id_ int, IN name_ varchar(20), IN birthDay_ date, IN class_id_ int)
begin
    update student set student_name = name_, birthday = birthDay_, class_id = class_id_ where id = id_;
end;

