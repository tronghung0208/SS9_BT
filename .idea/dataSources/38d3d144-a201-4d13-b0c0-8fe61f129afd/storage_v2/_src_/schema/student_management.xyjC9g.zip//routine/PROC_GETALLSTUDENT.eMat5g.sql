create
    definer = root@localhost procedure PROC_GETALLSTUDENT()
begin
    select s.id, s.student_name,s.birthday, s.class_id,c.name as className  from student s join class c on c.id = s.class_id;
end;

